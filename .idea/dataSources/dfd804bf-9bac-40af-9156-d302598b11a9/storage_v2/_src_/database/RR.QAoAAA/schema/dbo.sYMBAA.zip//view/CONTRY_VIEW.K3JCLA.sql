CREATE VIEW CONTRY_VIEW AS
 SELECT distinct CountryCode as id, CountryName as label from ContractSearchResult
go

