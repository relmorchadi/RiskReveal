CREATE VIEW CEDANT_VIEW AS
 SELECT distinct CedantCode as id, CedantName as label  FROM ContractSearchResult
go

