CREATE VIEW WORKSPACE_YEARS AS
SELECT distinct UwYear FROM ContractSearchResult
go

