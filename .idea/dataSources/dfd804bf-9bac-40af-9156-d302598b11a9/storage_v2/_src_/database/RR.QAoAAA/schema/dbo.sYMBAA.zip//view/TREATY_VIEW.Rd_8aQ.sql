
CREATE VIEW TREATY_VIEW AS
 SELECT distinct Treatyid as id, TreatyName as label FROM ContractSearchResult
go

